﻿# Coze API Service - Baota Panel Deployment Guide

## Deployment Steps

### 1. Upload Files
Extract this package to /www/wwwroot/coze-freeapi/ directory in Baota Panel

### 2. Install Dependencies
npm install --production --omit=dev

### 3. Configure Environment Variables
Edit .env file with database connection info

### 4. Create Database
Create database in Baota MySQL manager and import database/init.sql

### 5. Configure Node.js Project
Startup file: /www/wwwroot/coze-freeapi/dist/api/app.js

### 6. Start Service
Click start button in Node project management page

Generated: 2025-10-14 22:19:41
